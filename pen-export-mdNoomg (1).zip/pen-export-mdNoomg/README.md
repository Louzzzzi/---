# проект: "світ науки"

A Pen created on CodePen.io. Original URL: [https://codepen.io/Louzzzi-the-scripter/pen/mdNoomg](https://codepen.io/Louzzzi-the-scripter/pen/mdNoomg).

